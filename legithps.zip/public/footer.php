<footer class="container-footer">
    <div class="footer">
        <p>&copy; 2025 Emmié by HappySkin. All rights reserved.</p>
        <p>Liên hệ: support@happyskin.vn | Hotline: xxxx-xxx-xxx</p>
    </div>
</footer>