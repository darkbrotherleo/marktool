<div class="column">
    <div class="instruction">
        <h3>Hướng dẫn kiểm tra:</h3>
        <img src="./uploads/67c0b51b466e5_tem-check-legit.png" alt="Emmié by HappySkin" class="banner-img">
        <p><strong>Bước 1:</strong> Chụp hình bao bì sản phẩm, quay video kiểm tra mã code.</p>
        <p><strong>Bước 2:</strong> Điền đầy đủ thông tin để xác thực form để được kiểm mã.</p>
        <p><strong>Bước 3:</strong> Sau khi kiểm tra thành công, quý khách sẽ nhận được voucher từ Emmié by HappySkin.</p>
    </div>
</div>